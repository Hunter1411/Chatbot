package ChatBot;
/**
 * 
 * @author Soumyadip Chowdhury
 * @github soumyadip007
 *
 */
public class ChatBot {

	public static void main(String[] args) {
		ChatBotMain obj=new ChatBotMain();
		obj.setTitle("ChatBot(Team-Cognito)");
		obj.setVisible(true);
	}
}
